package com.exercise.formsubmission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormSubmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
